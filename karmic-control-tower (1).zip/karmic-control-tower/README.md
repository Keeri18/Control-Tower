# Fulfillment Control Tower

## Run it
No install. Unzip and double-click `index.html` (Chrome, Edge or Safari). Works offline; fonts fall back to system fonts without internet. Progress saves in your browser. "Reset demo" restores the sample data.

## Sample data (in /data)
Invented for the demo: 22 SKUs, 46 orders (55% Amazon, Own site, Alibaba), 3 couriers, 4 inbound deliveries. The app loads this data itself; the CSVs are for reference, and `orders_import_demo.csv` is for the import demo.

## Suggested 5-minute demo
1. Role: Operations lead. Read the Control tower: priority, late, at-risk, exceptions by owner.
2. Press +30 min. Watch orders turn amber and red.
3. Warehouse floor: open the batch pick list, then pick the order containing 3 x BWL-8 (needs a Warehouse B move) and scan a wrong variant.
4. Report "Can't find it" on CUT-SP. See the hold and the exception.
5. Pack: tick the checklist, scan the label, place the box in its bay.
6. Dispatch: confirm courier collection. Press +30 min past a courier pickup with a box not yet staged to see a missed pickup.
7. Inventory and Receiving: book in GRN-31 with damaged units, put away.
8. Control tower: import `data/orders_import_demo.csv` (shows duplicate and unknown-SKU checks). Open Audit log and Daily summary.

Any USB barcode scanner works as-is: it types into the scan box.

## Added in v3
Order detail with lifecycle and activity (click an order number), ACT NOW / WATCH / HEALTHY decision panel, exception SLAs (30 min priority, 2 h normal), Analytics tab, Products / SKU master (edit reorder level, deactivate SKUs), days of cover and reorder quantity on Inventory, purchase-order context on Receiving, and an import preview with row-level validation (the demo file has a duplicate, an unknown SKU and a missing quantity).
